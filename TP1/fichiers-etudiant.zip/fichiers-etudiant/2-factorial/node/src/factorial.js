/**
 * Return the factorial of i.
 * @param {number} i - an integer number.
 * @return {number} the factorial of i.
 */
let factorial = function (i) {
  // À compléter.
};

module.exports = factorial;
